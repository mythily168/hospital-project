module.exports = {
    secret: 'H_I_P'
  };